import { Component } from '@angular/core';

@Component({
  selector: 'app-ads1',
  standalone: false,
  templateUrl: './ads1.html',
  styleUrl: './ads1.css',
})
export class Ads1 {

}
